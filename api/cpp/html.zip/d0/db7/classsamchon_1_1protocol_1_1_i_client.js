var classsamchon_1_1protocol_1_1_i_client =
[
    [ "BUFFER_SIZE", "d0/db7/classsamchon_1_1protocol_1_1_i_client.html#aeb5632980254d2e48c5522ecba26d338", null ],
    [ "listen", "d0/db7/classsamchon_1_1protocol_1_1_i_client.html#a2c36bef1ddcc101dd1e1364ab22f4ee3", null ],
    [ "sendData", "d0/db7/classsamchon_1_1protocol_1_1_i_client.html#a44d95d1c5fb75aed2f41a5b4cca0df9e", null ],
    [ "socket", "d0/db7/classsamchon_1_1protocol_1_1_i_client.html#af61f5e26383c9eba182d578f1572e89c", null ],
    [ "sendMtx", "d0/db7/classsamchon_1_1protocol_1_1_i_client.html#aed772851e668352566c18806fc6456f4", null ]
];