var classsamchon_1_1protocol_1_1_entity =
[
    [ "Entity", "d1/d2d/classsamchon_1_1protocol_1_1_entity.html#a980f368aa07ce358583982821533a54a", null ],
    [ "TAG", "d1/d2d/classsamchon_1_1protocol_1_1_entity.html#a4cc6368fbbc98adcad05b511f3b51f04", null ],
    [ "key", "d1/d2d/classsamchon_1_1protocol_1_1_entity.html#ad03f41f168359dc5860f70b2d27fe8bf", null ],
    [ "construct", "d1/d2d/classsamchon_1_1protocol_1_1_entity.html#a9e73dda626b42f93db0fe5f749614b6d", null ],
    [ "toXML", "d1/d2d/classsamchon_1_1protocol_1_1_entity.html#abb38a9405acff9d13986019240151c54", null ]
];