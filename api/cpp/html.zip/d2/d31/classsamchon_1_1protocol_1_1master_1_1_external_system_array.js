var classsamchon_1_1protocol_1_1master_1_1_external_system_array =
[
    [ "ExternalSystemArray", "d2/d31/classsamchon_1_1protocol_1_1master_1_1_external_system_array.html#aebd8bf0f34b16f6316788c2f5d667bfc", null ],
    [ "TAG", "d2/d31/classsamchon_1_1protocol_1_1master_1_1_external_system_array.html#a0ff53d112100884fa1b880b331a75785", null ],
    [ "CHILD_TAG", "d2/d31/classsamchon_1_1protocol_1_1master_1_1_external_system_array.html#ab6cd81b578affa0b944b3688f61770ac", null ],
    [ "start", "d2/d31/classsamchon_1_1protocol_1_1master_1_1_external_system_array.html#a1950094772db354b7448efa252749e39", null ],
    [ "createRole", "d2/d31/classsamchon_1_1protocol_1_1master_1_1_external_system_array.html#a5d10032b3cafeb449dcbdae9ad9c61db", null ],
    [ "sendData", "d2/d31/classsamchon_1_1protocol_1_1master_1_1_external_system_array.html#a9f4470619965471aed9a78566a626477", null ]
];