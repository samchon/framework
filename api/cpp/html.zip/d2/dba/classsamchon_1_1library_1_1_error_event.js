var classsamchon_1_1library_1_1_error_event =
[
    [ "ErrorEvent", "d2/dba/classsamchon_1_1library_1_1_error_event.html#a08edf806dfee5821d1eeacf9d4b4b0b3", null ],
    [ "getID", "d2/dba/classsamchon_1_1library_1_1_error_event.html#a6df62b922057a9caa0decfc609ecf690", null ],
    [ "id", "d2/dba/classsamchon_1_1library_1_1_error_event.html#a369a5b79f405597537b3d48b03442ceb", null ]
];