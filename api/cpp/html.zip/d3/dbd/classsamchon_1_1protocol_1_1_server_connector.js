var classsamchon_1_1protocol_1_1_server_connector =
[
    [ "ServerConnector", "d3/dbd/classsamchon_1_1protocol_1_1_server_connector.html#a04cc1e256a218c337afd9f3e0bcad38f", null ],
    [ "IP", "d3/dbd/classsamchon_1_1protocol_1_1_server_connector.html#a8b793a9c3c80a4065ea1a5390eec00b4", null ],
    [ "PORT", "d3/dbd/classsamchon_1_1protocol_1_1_server_connector.html#a042f79ebec3f348ec0b6906fd20e60e1", null ],
    [ "MY_IP", "d3/dbd/classsamchon_1_1protocol_1_1_server_connector.html#a92c72fe13dd34cfe4cd89de4069a4867", null ],
    [ "connect", "d3/dbd/classsamchon_1_1protocol_1_1_server_connector.html#a562adfa91306c7736a381ba52e3ad1b5", null ]
];