var classsamchon_1_1protocol_1_1_one_to_one_server =
[
    [ "OneToOneServer", "d3/de2/classsamchon_1_1protocol_1_1_one_to_one_server.html#aaed8d0fc86e117e3c005c0a6989ed1c7", null ],
    [ "addClient", "d3/de2/classsamchon_1_1protocol_1_1_one_to_one_server.html#a19fdd0e5445444840231663064058d6f", null ]
];