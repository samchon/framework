var classsamchon_1_1protocol_1_1service_1_1_user =
[
    [ "User", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#ac7f2817cc2123ce17679cb5b9d745883", null ],
    [ "getServer", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a419357131cfb6a3199620279d118c55a", null ],
    [ "getSemaphore", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#aa7870fbe3ac9d051d7933932bf5a2ba5", null ],
    [ "getID", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a5f4842eca0cd8e7e9fe8807cdb9e3fb2", null ],
    [ "getAuthority", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a9ec6f86c233412fcf8f1acd77374a285", null ],
    [ "createClient", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a0d5d8cfb0f95627c808377b49ec86a45", null ],
    [ "addClient", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#aca542acb24621ebd4cd778f55d26d7e2", null ],
    [ "eraseClient", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a33b8200943e4cdec920453554d5fc644", null ],
    [ "goLogin", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#af0ff5b21b652129519b79f3472e60a89", null ],
    [ "goJoin", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a2410e570529908b9e1304e407bc99e84", null ],
    [ "goLogout", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a6ab791ecf7f5a1cf3788a09308985432", null ],
    [ "doLogin", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a31746ea0d4e21eb3ade51f4d93326d0d", null ],
    [ "doJoin", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a3ae208b83139739e4e52d05b472ee815", null ],
    [ "server", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a25fd470c66d0c6eecab5c8cae0d20c07", null ],
    [ "sessionID", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#ae5f12343f2fda70d152946b8ace9ffed", null ],
    [ "mtx", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#aad765f2823546eca40b178cd28550145", null ],
    [ "semaphore", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a2d5837c2130808f4f18a4508482f5e5f", null ],
    [ "id", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#ae91fdcd1022f0c91f8d9004f41a59ce5", null ],
    [ "authority", "d4/d98/classsamchon_1_1protocol_1_1service_1_1_user.html#a72e0c739dca4fda56c53db1b4d8709f4", null ]
];