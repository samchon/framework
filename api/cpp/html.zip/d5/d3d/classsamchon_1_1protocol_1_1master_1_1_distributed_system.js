var classsamchon_1_1protocol_1_1master_1_1_distributed_system =
[
    [ "construct", "d5/d3d/classsamchon_1_1protocol_1_1master_1_1_distributed_system.html#a053735c5881979aea7023682bbcc4ff2", null ],
    [ "toXML", "d5/d3d/classsamchon_1_1protocol_1_1master_1_1_distributed_system.html#a493bda411b5ac9919ac591fd02fe4fc5", null ],
    [ "performance", "d5/d3d/classsamchon_1_1protocol_1_1master_1_1_distributed_system.html#a7694d110dbb9300a3ee003e95a345a12", null ]
];