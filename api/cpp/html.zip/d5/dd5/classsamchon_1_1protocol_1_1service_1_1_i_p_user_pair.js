var classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair =
[
    [ "IPUserPair", "d5/dd5/classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair.html#a9662cb3e808fe12341ba0cfe420e9fe6", null ],
    [ "getSessionID", "d5/dd5/classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair.html#a9b85586e628d6ed46079a1483f4d7cd7", null ],
    [ "issueSessionID", "d5/dd5/classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair.html#a478708855138841c6089d6cb04b6b02e", null ],
    [ "server", "d5/dd5/classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair.html#a9dcc734800a3c6ecfb04dc118ea3b3c5", null ],
    [ "ip", "d5/dd5/classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair.html#a5899a025cc9a80140ddb496b203cc0b2", null ],
    [ "userSet", "d5/dd5/classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair.html#ad5afa3b72b353bb8710024b17b32f1c3", null ],
    [ "mtx", "d5/dd5/classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair.html#a168d2b9477f301410d508edcbd1e7745", null ]
];