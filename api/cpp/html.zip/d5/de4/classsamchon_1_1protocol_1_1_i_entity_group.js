var classsamchon_1_1protocol_1_1_i_entity_group =
[
    [ "IEntityGroup", "d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html#ab21e3029796592cd3ff78b900b24009f", null ],
    [ "CHILD_TAG", "d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html#a9943f8315a53b67873adc40afb6bc972", null ],
    [ "has", "d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html#a981914c18a6c1e35d1ab48cc14929b11", null ],
    [ "get", "d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html#a4726434239db7661309f72337e36fff0", null ],
    [ "get", "d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html#a22cf6eb434f57d430a0363a624d60417", null ],
    [ "construct", "d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html#a49d8651b7ba3cffe5e2e44710a61bceb", null ],
    [ "toXML", "d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html#aa00df91c3b413465b854184d49390dd9", null ],
    [ "createChild", "d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html#af01351b378aace857f95b4f8d5265122", null ]
];