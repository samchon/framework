var classsamchon_1_1protocol_1_1_i_server =
[
    [ "MY_IP", "d8/d4e/classsamchon_1_1protocol_1_1_i_server.html#ae427b3fdb24dfaaa8bb30b264658fb36", null ],
    [ "PORT", "d8/d4e/classsamchon_1_1protocol_1_1_i_server.html#a1bee88a3b4508af65b7e9796157562db", null ],
    [ "open", "d8/d4e/classsamchon_1_1protocol_1_1_i_server.html#ac902fd72d7fee9bcd618819393bf4ab0", null ],
    [ "close", "d8/d4e/classsamchon_1_1protocol_1_1_i_server.html#a6ecfd4d9e3117e6487f1afca209e8470", null ],
    [ "addClient", "d8/d4e/classsamchon_1_1protocol_1_1_i_server.html#afadeb5cb06acc8e59e336e5884a8ef76", null ]
];