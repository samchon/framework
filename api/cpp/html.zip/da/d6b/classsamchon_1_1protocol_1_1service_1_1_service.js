var classsamchon_1_1protocol_1_1service_1_1_service =
[
    [ "Service", "da/d6b/classsamchon_1_1protocol_1_1service_1_1_service.html#a5b8b2cb48cf38c22da5e9d8adcca807d", null ],
    [ "NAME", "da/d6b/classsamchon_1_1protocol_1_1service_1_1_service.html#ade9f2cbce99fb08a1d5768a47355820e", null ],
    [ "REQUIRE_AUTHORITY", "da/d6b/classsamchon_1_1protocol_1_1service_1_1_service.html#aad91285df95f15c577b8beca3a2da319", null ],
    [ "getClient", "da/d6b/classsamchon_1_1protocol_1_1service_1_1_service.html#a54ae4aaec78d376d378f5bfb4056b2b6", null ],
    [ "sendData", "da/d6b/classsamchon_1_1protocol_1_1service_1_1_service.html#abf3980854281a448cbf326f90eb7a0f6", null ],
    [ "client", "da/d6b/classsamchon_1_1protocol_1_1service_1_1_service.html#abdf6203c973cc1bc797561b73fa87cc4", null ]
];