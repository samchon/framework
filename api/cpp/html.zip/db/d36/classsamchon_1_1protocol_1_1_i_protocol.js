var classsamchon_1_1protocol_1_1_i_protocol =
[
    [ "replyData", "db/d36/classsamchon_1_1protocol_1_1_i_protocol.html#a6760c7213201af3ad99e48808d46ccfb", null ],
    [ "sendData", "db/d36/classsamchon_1_1protocol_1_1_i_protocol.html#a522a5cfdb02c515d65e7caa1b90f323f", null ]
];