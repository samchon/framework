var classsamchon_1_1library_1_1_i_f_t_file =
[
    [ "IFTFile", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#a9c73e1541b7040642bf32afee5dffd96", null ],
    [ "TAG", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#a32cc06d5414e007b4edc4cf0a2b543ba", null ],
    [ "key", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#a21439f81727bdfa528215158edc1b8a5", null ],
    [ "getUID", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#a9e651accc10a29d768565add163260b2", null ],
    [ "getParent", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#a9e3466f81d72a0cf87018996b5934738", null ],
    [ "getName", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#ab1758e2900ee75c534f8a9b170b2400e", null ],
    [ "getComment", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#a575cf09d6c16055828d84cff5031b069", null ],
    [ "toXML", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#a182bd68d639e7d77eb0159a4c0b9e854", null ],
    [ "parent", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#acc1702e1808799f4fd917745c2e13cb5", null ],
    [ "uid", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#ac22c3613b918314966bea332f63e041d", null ],
    [ "name", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#ac5433955d54f8eb191ef3e6bf985323d", null ],
    [ "comment", "db/d63/classsamchon_1_1library_1_1_i_f_t_file.html#a5c8354e94dbeea1ea0b4e9d6d0187bb8", null ]
];