var classsamchon_1_1library_1_1_event =
[
    [ "Event", "db/df5/classsamchon_1_1library_1_1_event.html#a2b77e0cf6800331b5ca1fa03e975e7d1", null ],
    [ "getSource", "db/df5/classsamchon_1_1library_1_1_event.html#a68a128c093ba5ad3c415fc64d1224ad8", null ],
    [ "getType", "db/df5/classsamchon_1_1library_1_1_event.html#a304d366987980085a052d017e30342b7", null ],
    [ "source", "db/df5/classsamchon_1_1library_1_1_event.html#a4a1f085faecf6b69fe99a28d1fd9368d", null ],
    [ "type", "db/df5/classsamchon_1_1library_1_1_event.html#a9d320b88ed35b413642980310ed9332b", null ]
];