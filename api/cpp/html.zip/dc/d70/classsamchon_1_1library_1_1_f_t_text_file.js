var classsamchon_1_1library_1_1_f_t_text_file =
[
    [ "FTTextFile", "dc/d70/classsamchon_1_1library_1_1_f_t_text_file.html#a82f6419a03170ac96fea8eb08171798d", null ],
    [ "toXML", "dc/d70/classsamchon_1_1library_1_1_f_t_text_file.html#ab0760f366b4ebfbfe0904b639258a6cd", null ],
    [ "data", "dc/d70/classsamchon_1_1library_1_1_f_t_text_file.html#a0ed15e43f62348594a14fa7e665d3e89", null ]
];