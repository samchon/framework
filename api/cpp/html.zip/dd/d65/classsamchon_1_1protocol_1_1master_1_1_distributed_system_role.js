var classsamchon_1_1protocol_1_1master_1_1_distributed_system_role =
[
    [ "construct", "dd/d65/classsamchon_1_1protocol_1_1master_1_1_distributed_system_role.html#a93290dbe013d9ae333ed529086e37377", null ],
    [ "toXML", "dd/d65/classsamchon_1_1protocol_1_1master_1_1_distributed_system_role.html#a5aecb1b352ccf76b515ab70cd4569ccc", null ],
    [ "performance", "dd/d65/classsamchon_1_1protocol_1_1master_1_1_distributed_system_role.html#aa2077efeea63b5386dd64ac50b1a870c", null ]
];