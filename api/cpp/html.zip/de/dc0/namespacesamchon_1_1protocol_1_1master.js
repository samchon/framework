var namespacesamchon_1_1protocol_1_1master =
[
    [ "DistributedSystem", "d5/d3d/classsamchon_1_1protocol_1_1master_1_1_distributed_system.html", "d5/d3d/classsamchon_1_1protocol_1_1master_1_1_distributed_system" ],
    [ "DistributedSystemArray", "d3/dd3/classsamchon_1_1protocol_1_1master_1_1_distributed_system_array.html", null ],
    [ "DistributedSystemRole", "dd/d65/classsamchon_1_1protocol_1_1master_1_1_distributed_system_role.html", "dd/d65/classsamchon_1_1protocol_1_1master_1_1_distributed_system_role" ],
    [ "ExternalSystem", "de/daa/classsamchon_1_1protocol_1_1master_1_1_external_system.html", "de/daa/classsamchon_1_1protocol_1_1master_1_1_external_system" ],
    [ "ExternalSystemArray", "d2/d31/classsamchon_1_1protocol_1_1master_1_1_external_system_array.html", "d2/d31/classsamchon_1_1protocol_1_1master_1_1_external_system_array" ]
];