var classsamchon_1_1protocol_1_1service_1_1_client =
[
    [ "Client", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#a75b0b095debaa5213fdc67cb3da0e35c", null ],
    [ "createService", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#af023ed8c291f90b59a47ded93ae16c4a", null ],
    [ "getUser", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#a6002341b55090f1d83ea3b53b160e846", null ],
    [ "getService", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#ad1c88a817e3f8e91a18303b55200258d", null ],
    [ "getNo", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#ab23c385f7cc020993e86ddf1440d9f6e", null ],
    [ "sendData", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#ac4852bf9ea2a070f3940ec7ed4d3dc6a", null ],
    [ "replyData", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#ae9e8bc11e9affaa94cf009520bb4348e", null ],
    [ "constructService", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#adac559c8a6ce56ef133e23a1bf07cb70", null ],
    [ "user", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#a361d83231e00f122c10f8cfe453db4c3", null ],
    [ "no", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#afad10012006f4dfa5b58d5cf527112c8", null ],
    [ "service", "df/dcb/classsamchon_1_1protocol_1_1service_1_1_client.html#a455ceb981259aaba3201ffdf3e1d09a8", null ]
];