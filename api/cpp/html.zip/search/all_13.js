var searchData=
[
  ['value',['value',['../d3/d02/classsamchon_1_1library_1_1_x_m_l.html#a140fd18830c788f27dcee0bf5958845b',1,'samchon::library::XML']]],
  ['variance_5fp',['variance_p',['../d1/d21/classsamchon_1_1library_1_1_math.html#a618752b265abfc9df8150db3d7c66b34',1,'samchon::library::Math']]],
  ['variance_5fs',['variance_s',['../d1/d21/classsamchon_1_1library_1_1_math.html#a64fcfaf3f77e1d2cbc0c4a3fd5e1c60f',1,'samchon::library::Math']]]
];
