var searchData=
[
  ['iclient',['IClient',['../d0/db7/classsamchon_1_1protocol_1_1_i_client.html',1,'samchon::protocol']]],
  ['ientitygroup',['IEntityGroup',['../d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html',1,'samchon::protocol']]],
  ['ientitygroup_3c_20_5fcontainer_2c_20entity_20_2a_20_3e',['IEntityGroup&lt; _Container, Entity * &gt;',['../d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html',1,'samchon::protocol']]],
  ['ientitygroup_3c_20_5fcontainer_2c_20std_3a_3ashared_5fptr_3c_20entity_20_3e_20_3e',['IEntityGroup&lt; _Container, std::shared_ptr&lt; Entity &gt; &gt;',['../d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html',1,'samchon::protocol']]],
  ['ientitygroup_3c_20_5fcontainer_2c_20std_3a_3aunique_5fptr_3c_20entity_20_3e_20_3e',['IEntityGroup&lt; _Container, std::unique_ptr&lt; Entity &gt; &gt;',['../d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html',1,'samchon::protocol']]],
  ['ientitygroup_3c_20std_3a_3avector_3c_20std_3a_3ashared_5fptr_3c_20entity_20_3e_20_3e_2c_20std_3a_3ashared_5fptr_3c_20entity_20_3e_20_3e',['IEntityGroup&lt; std::vector&lt; std::shared_ptr&lt; Entity &gt; &gt;, std::shared_ptr&lt; Entity &gt; &gt;',['../d5/de4/classsamchon_1_1protocol_1_1_i_entity_group.html',1,'samchon::protocol']]],
  ['ientityptrgroup',['IEntityPtrGroup',['../d3/d23/classsamchon_1_1protocol_1_1_i_entity_ptr_group.html',1,'samchon::protocol']]],
  ['iftfile',['IFTFile',['../db/d63/classsamchon_1_1library_1_1_i_f_t_file.html',1,'samchon::library']]],
  ['indexpair',['IndexPair',['../d2/d72/classsamchon_1_1_index_pair.html',1,'samchon']]],
  ['intexplore',['INTExplore',['../d0/d04/classsamchon_1_1namtree_1_1_i_n_t_explore.html',1,'samchon::namtree']]],
  ['ioperator',['IOperator',['../da/d70/classsamchon_1_1library_1_1_i_operator.html',1,'samchon::library']]],
  ['iprotocol',['IProtocol',['../db/d36/classsamchon_1_1protocol_1_1_i_protocol.html',1,'samchon::protocol']]],
  ['ipuserpair',['IPUserPair',['../d5/dd5/classsamchon_1_1protocol_1_1service_1_1_i_p_user_pair.html',1,'samchon::protocol::service']]],
  ['iserver',['IServer',['../d8/d4e/classsamchon_1_1protocol_1_1_i_server.html',1,'samchon::protocol']]],
  ['isqlentity',['ISQLEntity',['../de/dac/classsamchon_1_1protocol_1_1_i_s_q_l_entity.html',1,'samchon::protocol']]]
];
