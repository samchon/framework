#include <samchon/protocol/master/MediatorServerSocket.hpp>
#	include <samchon/protocol/master/ExternalServerArrayMediator.hpp>

#include <samchon/protocol/Invoke.hpp>