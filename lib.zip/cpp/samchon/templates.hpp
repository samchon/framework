#pragma once

#include <samchon/templates/service.hpp>

#include <samchon/templates/external.hpp>
#include <samchon/templates/parallel.hpp>
#include <samchon/templates/distributed.hpp>
#include <samchon/templates/slave.hpp>