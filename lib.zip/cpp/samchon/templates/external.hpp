#pragma once

#include <samchon/templates/external/ExternalSystemArray.hpp>
#	include <samchon/templates/external/ExternalServerArray.hpp>
#	include <samchon/templates/external/ExternalClientArray.hpp>
#	include <samchon/templates/external/ExternalServerClientArray.hpp>

#include <samchon/templates/external/ExternalSystem.hpp>
#	include <samchon/templates/external/ExternalServer.hpp>

#include <samchon/templates/external/ExternalSystemRole.hpp>