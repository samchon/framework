#pragma once

#include <samchon/templates/slave/SlaveSystem.hpp>
#include <samchon/templates/slave/SlaveServer.hpp>
#include <samchon/templates/slave/SlaveClient.hpp>

#include <samchon/templates/slave/PInvoke.hpp>
#include <samchon/templates/slave/InvokeHistory.hpp>