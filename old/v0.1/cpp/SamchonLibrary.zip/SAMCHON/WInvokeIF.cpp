#include <samchon/IInvoke.hpp>

namespace samchon
{
	IWInvoke::IBasicInvoke() {}
	template<> IWInvoke::~IBasicInvoke() {}
};